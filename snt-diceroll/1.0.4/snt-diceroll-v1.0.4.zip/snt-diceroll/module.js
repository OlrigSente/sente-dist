let e = null;
function n() {
  if (e) return e;
  const o = globalThis == null ? void 0 : globalThis.Hooks;
  if (!o) throw new Error("[snt-core] Foundry Hooks global not found");
  return e = o, o;
}
const t = {
  on: (...o) => n().on(...o),
  once: (...o) => n().once(...o),
  off: (...o) => n().off(...o),
  callAll: (...o) => n().callAll(...o),
  call: (...o) => n().call(...o)
}, l = {
  id: "snt-core",
  log: (...o) => console.log("[snt-core]", ...o),
  hooks: t,
  provide(o) {
    var s;
    const c = (s = game.modules) == null ? void 0 : s.get(this.id);
    c && (c.api = o);
  }
};
l.hooks.once("init", () => l.log("init"));
l.hooks.once("ready", () => l.log("ready"));
l.hooks.once("init", () => {
  l.log("diceroll init");
});
l.hooks.on("ready", async () => {
  l.log("diceroll ready -> test roll");
});
//# sourceMappingURL=module.js.map
