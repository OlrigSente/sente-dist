export declare const SNT: {
    id: string;
    log: (...args: unknown[]) => void;
    hooks: import("./hooks").HooksAPI;
    provide(api: unknown): void;
};
