export interface HooksAPI {
    on(event: string | string[], fn: (...args: any[]) => unknown, context?: unknown, priority?: number): number;
    once(event: string | string[], fn: (...args: any[]) => unknown, context?: unknown, priority?: number): number;
    off(event: string | string[], fn: (...args: any[]) => unknown): number;
    callAll(event: string, ...args: any[]): void;
    call(event: string, ...args: any[]): boolean;
}
/** Fa�ade namespac�e */
export declare const hooks: HooksAPI;
