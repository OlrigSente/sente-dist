let e = null;
function l() {
  if (e) return e;
  const o = globalThis == null ? void 0 : globalThis.Hooks;
  if (!o) throw new Error("[snt-core] Foundry Hooks global not found");
  return e = o, o;
}
const t = {
  on: (...o) => l().on(...o),
  once: (...o) => l().once(...o),
  off: (...o) => l().off(...o),
  callAll: (...o) => l().callAll(...o),
  call: (...o) => l().call(...o)
}, n = {
  id: "snt-core",
  log: (...o) => console.log("[snt-core]", ...o),
  hooks: t,
  provide(o) {
    var s;
    const c = (s = game.modules) == null ? void 0 : s.get(this.id);
    c && (c.api = o);
  }
};
n.hooks.once("init", () => n.log("init"));
n.hooks.once("ready", () => n.log("ready"));
export {
  n as SNT
};
//# sourceMappingURL=module.js.map
